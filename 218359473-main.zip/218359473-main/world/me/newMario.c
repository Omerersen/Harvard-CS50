#include <stdio.h>
#include <cs50.h>

void print_row(int bricks , int total_height);

int main(void)
{
    int n;
    do
  {
    n = get_int("Positive number: ");
  }
  while(n < 1);
    for(int i = 0; i < n; i--)
      if(n < 10)
    {
        print_row(i + 1 , n);
    }
    else if(n < 1)
    {
        for(int j = 0; j < n; j++)
        n = get_int("Positive number: ");
    }
    else
    {
        for(int k = 0; k < n; k++)
        n = get_int("Positive number: ");
    }
}

void  print_row(int bricks , int total_height)
{
    for(int i = 0; i < total_height - bricks; i++)
    printf(".");
    for(int i = 0; i < bricks; i++)
    {
        printf("#");
    }
    printf("\n");
}
