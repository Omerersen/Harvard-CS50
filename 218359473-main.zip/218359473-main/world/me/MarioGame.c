#include <stdio.h>
#include <cs50.h>

void print_row(int bricks, int total_width);

int main(void)
{

    int height = get_int("Positive Number: ");

    if(height < 8)
    {
    for (int i = 1; i <= height; i++)
      {
        print_row(i, height);
      }
    }
    else
    {
        int heightAgain = get_int("Try Again: ");
     for (int i = 1; i <= heightAgain; i++)
      {
        print_row(i, heightAgain);
      }
    }
}



void print_row(int bricks, int total_width)
{
    // önce boşluk
    for (int i = 0; i < total_width - bricks; i++)
    {
        printf(" ");
    }

    // sonra tuğlalar
    for (int i = 0; i < bricks; i++)
    {
        printf("#");
    }
    for (int i = 0; i < 5; i++)
    {
      printf(".");
    }
    for (int i = 0; i < bricks; i++)
    {
      printf("#");
    }
    printf("\n");
}
